import React from "react";

function formatDate(ts) {
  return new Date(ts).toLocaleString();
}

export default function EntryList({ entries = [], onDelete }) {
  if (!entries.length) return <p className="empty">No entries yet.</p>;

  return (
    <div className="list">
      {entries.map((e) => (
        <article key={e.createdAt} className="entry">
          <header>
            <time>{formatDate(e.createdAt)}</time>
            <button onClick={() => onDelete(e.createdAt)}>Delete</button>
          </header>
          <pre className="entry-text">{e.encrypted ? e.text || "[encrypted]" : e.text}</pre>
        </article>
      ))}
    </div>
  );
}