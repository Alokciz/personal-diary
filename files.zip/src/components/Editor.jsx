import React, { useState } from "react";

export default function Editor({ onSave, disabled }) {
  const [text, setText] = useState("");

  function submit(e) {
    e.preventDefault();
    if (!text.trim()) return;
    onSave(text.trim());
    setText("");
  }

  return (
    <form onSubmit={submit} className="editor">
      <textarea
        placeholder="Write your entry..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={6}
        disabled={!disabled}
      />
      <div className="editor-actions">
        <button type="submit" disabled={!disabled}>Save Entry</button>
      </div>
    </form>
  );
}