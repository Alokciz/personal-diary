import React, { useEffect, useState } from "react";
import EntryList from "./components/EntryList";
import Editor from "./components/Editor";
import { initDB, getAllEntries, saveEntry, deleteEntry } from "./db";
import { deriveKey, encryptText, decryptText } from "./crypto";

export default function App() {
  const [entries, setEntries] = useState([]);
  const [passphrase, setPassphrase] = useState("");
  const [useEncryption, setUseEncryption] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    async function start() {
      await initDB();
      setReady(true);
      await load();
    }
    start();
  }, []);

  async function load() {
    const all = await getAllEntries();
    if (useEncryption && passphrase) {
      // attempt decrypt; entries include iv and salt per record
      const decrypted = await Promise.all(
        all.map(async (e) => {
          try {
            const key = await deriveKey(passphrase, e.salt);
            const txt = await decryptText(key, e.iv, e.payload);
            return { ...e, text: txt };
          } catch {
            return { ...e, text: "[decryption failed]" };
          }
        })
      );
      setEntries(decrypted.sort((a, b) => b.createdAt - a.createdAt));
    } else {
      setEntries(all.sort((a, b) => b.createdAt - a.createdAt));
    }
  }

  async function handleSave(text) {
    const createdAt = Date.now();
    if (useEncryption && passphrase) {
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const key = await deriveKey(passphrase, salt);
      const { iv, ciphertext } = await encryptText(key, text);
      await saveEntry({
        createdAt,
        encrypted: true,
        payload: ciphertext,
        iv,
        salt
      });
    } else {
      await saveEntry({
        createdAt,
        encrypted: false,
        text
      });
    }
    await load();
  }

  async function handleDelete(id) {
    await deleteEntry(id);
    await load();
  }

  return (
    <div className="app">
      <header>
        <h1>Personal Diary</h1>
        <div className="controls">
          <label>
            <input
              type="checkbox"
              checked={useEncryption}
              onChange={(e) => setUseEncryption(e.target.checked)}
            />{" "}
            Encrypt entries
          </label>
          {useEncryption && (
            <input
              type="password"
              placeholder="Passphrase"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
            />
          )}
        </div>
      </header>

      <main>
        <Editor onSave={handleSave} disabled={!ready} />
        <EntryList entries={entries} onDelete={handleDelete} />
      </main>

      <footer>
        <small>Local-only diary (stored in your browser). Back up/export regularly.</small>
      </footer>
    </div>
  );
}