// Uses Web Crypto API: PBKDF2 -> AES-GCM
// Exports deriveKey(passphrase, saltUint8) -> CryptoKey
// encryptText(key, text) -> { iv: Uint8Array, ciphertext: ArrayBuffer }
// decryptText(key, ivUint8, ciphertext) -> plaintext string
// Note: save iv and salt as Uint8Array (we store raw bytes in IndexedDB via structured clone).

const enc = new TextEncoder();
const dec = new TextDecoder();

export async function deriveKey(passphrase, salt) {
  // salt: Uint8Array (if stored as ArrayBuffer from idb it's fine)
  if (!(salt instanceof Uint8Array)) salt = new Uint8Array(salt);
  const baseKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(passphrase),
    "PBKDF2",
    false,
    ["deriveKey"]
  );
  const key = await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt,
      iterations: 250000,
      hash: "SHA-256"
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
  return key;
}

export async function encryptText(key, text) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    enc.encode(text)
  );
  return { iv, ciphertext };
}

export async function decryptText(key, iv, ciphertext) {
  try {
    const plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv instanceof Uint8Array ? iv : new Uint8Array(iv) },
      key,
      ciphertext
    );
    return dec.decode(plain);
  } catch (e) {
    throw new Error("decryption-failed");
  }
}