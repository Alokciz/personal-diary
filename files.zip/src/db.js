import { openDB } from "idb";

const DB_NAME = "personal-diary";
const STORE = "entries";

let db;

export async function initDB() {
  db = await openDB(DB_NAME, 1, {
    upgrade(upgradeDb) {
      if (!upgradeDb.objectStoreNames.contains(STORE)) {
        upgradeDb.createObjectStore(STORE, { keyPath: "createdAt" });
      }
    }
  });
}

export async function saveEntry(entry) {
  // entry must include createdAt and either (text) or (encrypted:true, payload, iv, salt)
  return db.put(STORE, entry);
}

export async function getAllEntries() {
  return db.getAll(STORE);
}

export async function deleteEntry(createdAt) {
  return db.delete(STORE, createdAt);
}