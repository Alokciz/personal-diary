# Personal Diary (starter)

A small privacy-first personal diary web app (PWA-ready). Entries are stored locally in your browser (IndexedDB). Optional passphrase encryption uses the Web Crypto API (PBKDF2 + AES-GCM).

## Features (starter)
- Create and delete plain or encrypted entries
- Local storage (IndexedDB via idb)
- Client-side encryption with a passphrase (optional)
- Minimal UI; easy to extend

## Quick start
1. Install
   npm install
2. Run dev server
   npm run dev
3. Open http://localhost:5173 (or the address Vite shows)

## Notes on encryption & privacy
- If you enable "Encrypt entries" and provide a passphrase, each entry is encrypted with a random salt and iv. The passphrase is not stored anywhere.
- If you forget the passphrase you'll lose access to the encrypted entries.
- This starter keeps everything local. If you want syncing (Cloud, end-to-end encrypted sync), you can add a backend or use a sync service.

## Next ideas
- Add export/import (JSON) with optional encryption
- Add tags, search, and rich text/markdown rendering
- Turn into an Electron or React Native app to run offline on desktop/mobile
- Add biometric unlock when using native wrappers

Enjoy! If you'd like, I can:
- Add export/import feature
- Make this into an Electron or React Native app
- Add cloud sync (Firebase / Supabase) with E2EE
- Improve UI (dark mode, editor formatting)
Tell me which direction you'd like and I'll continue.